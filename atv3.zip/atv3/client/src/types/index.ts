export interface Potion {
  id?: number;
  nome: string;
  descricao: string;
  imagemUrl: string;
  preco: number;
}
